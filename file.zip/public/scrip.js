function fun(){
    console.log('scrip function');
    document.getElementById('errMessage').innerHTML='trtrtrttrrt';
}
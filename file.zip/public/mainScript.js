
console.log('main begin')

function search(){
 //var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var req = new XMLHttpRequest();
var url = '/';


req.open('post',url,true); // set this to POST if you would like
req.addEventListener('load',onLoad);
req.addEventListener('error',onError);
req.setRequestHeader("Content-Type", "text/plain; charset=UTF-8");
var celeb={celeb:document.getElementById('input')}
req.send(JSON.stringify(celeb));
}

function onLoad() {
   var response = this.responseText;
   var parsedResponse = JSON.parse(response);

   // access your data newly received data here and update your DOM with appendChild(), findElementById(), etc...
   var message = parsedResponse['message'];
   var url=parsedResponse['url'];
   //document.getElementById()
   if(url){
    document.getElementById('url').innerHTML=message;
    document.getElementById('url').href=url;

   }
   else{
    document.getElementById('errMessage').innerHTML=message;
   }

   // append child (with text value of messageToDisplay for instance) here or do some more stuff
}

function onError() {
  // handle error here, print message perhaps
  console.log('error receiving async AJAX call');
}







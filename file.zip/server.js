const CognitiveServicesCredentials = require('ms-rest-azure').CognitiveServicesCredentials;
const WebSearchAPIClient = require('azure-cognitiveservices-websearch');
//const scr = require("./mainScript");
const express = require('express');
const request = require('request');

const app = express();
const bodyParser = require('body-parser');

const instegram ="instegram"
const searchIn="webPages"
const firstResults=5;
const pattern="https://www.";



const MongoClient = require('mongodb').MongoClient;


var uri="mongodb+srv://Avremi:AHh72507250.@celebrities-uyr4n.azure.mongodb.net/celeb?retryWrites=true&w=majority"
//var uri = "mongodb://localhost:27017/mydb";





//const client = new CosmosClient({ endpoint: endpoint, auth: { masterKey: masterKey } });
//const { database } = await client.databases.createIfNotExists({ id: databaseId });



app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'html')
const path = require('path');

app.use(express.static(path.join(__dirname,'public')));








let credentials = new CognitiveServicesCredentials('dd24307509d8423ea5a0e72ddfe570b3');
let webSearchApiClient = new WebSearchAPIClient(credentials);



app.get('/', function (req, res) {
   
var celebritiesList;
   // MongoClient.connect(uri, function(err, db) {
        // Paste the following examples here
       // if (err) throw err;
     // var dbo = db.db("celeb");
      
      
     // celebritiesList= arrayResult=dbo.collection("names").find({}).toArray(function(err, result) {
        //if (err) throw err;
       // console.log(result);
        //db.close();
     // });
      //});
    //document.getElementById(errMessage).innerHTML="testtttttt";
    res.sendFile(path.join(__dirname,'/index.html'),{'message': null, 'url': null, 'celebritiesList':celebritiesList });

   //res.send('response')
   
  })
  
  
  app.listen(1337, function () {
    console.log('Example app listening on port 3000!')
  })

  app.post('/', function (req, res) {
      
    let celebrity = req.body;
    //console.log(req.body)
    //let celebrit=req.fname;
   // var member = JSON.parse( req.body );
    //console.log(member.fname);
    var dataToSendToClient;//=req.body.fname;
    var celebritiesList=null;
    webSearchApiClient.web.search(celebrity+" "+instegram).then((result) => {
        //let properties = ["images", "webPages", "news", "videos"];
       // for (let i = 0; i < properties.length; i++) {
        //var dataToSendToClient=null;
            
                let str= instegram+' account of '+celebrity;
                let url=findMatches(result[searchIn], instegram, firstResults);    //result[searchIn].value[0].snippet+"\n"+result[searchIn].value[0].url;
                console.log(str);
                if(url){

                    celebritiesList=updateDB(url,celebrity)

                    

                    let dataToSendToClient = {'message': str, 'url': url, 'celebritiesList':celebritiesList };
                    var JSONdata = JSON.stringify(dataToSendToClient);
    res.send(JSONdata);
                }
                else{

                    let dataToSendToClient = {'message': str +' not found', 'url': null,'celebritiesList':null };
                    var JSONdata = JSON.stringify(dataToSendToClient);
    res.send(JSONdata);
                }
                

                //res.sendFile(path.join(__dirname+'/public/index.html'),{page: str, error: null});


            

    }).catch((err) => {
         //res.sendFile(path.join(__dirname+'/public/index.html'));
         let dataToSendToClient = {'message': 'Error, please try again', 'url': null ,'celebritiesList':null};
         let JSONdata = JSON.stringify(dataToSendToClient);
    res.send(JSONdata);
         //res.sendFile(path.join(__dirname+'/index.html'),dataToSendToClient);

    })

    
 


  });


  function findMatches(results,searchFor,firstResults){
      if(results){
          resultValues=results.value;
        for(let i=0;i<firstResults;i++){
            if(match(resultValues[i],searchFor)){
                return resultValues[i].url;
            }
        }
      }
      return null;
  }

  function match(value,searchFor){
    let url=value.url;
    let fullPattern=pattern+searchFor;
      
      return url.length>fullPattern.length; //&& fullPattern==url.substr(0,fullPattern.length);

  }

function updateDB(url,celebrity){

    var arrayResult;
    MongoClient.connect(uri, function(err, db) {
        // Paste the following examples here
        if (err) console.log( err);
        if(!db) console.log('db=null');
      var dbo = db.db("celeb");
      var celeb = { '_id': celebrity, 'url':url };
      dbo.collection("names").insertOne(celeb, function(err, res) {
        // if (err) throw err;
        console.log("1 document inserted");
      });
      arrayResult=dbo.collection("names").find({}).toArray(function(err, result) {
        //if (err) throw err;
        console.log(result);
        db.close();
      });
      });

      return arrayResult;
}
  